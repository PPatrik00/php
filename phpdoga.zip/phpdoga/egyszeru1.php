<?php
for($x=1; $x<=10; $x++){
    echo '<br>';
    for($z=1 ; $z <= 10; $z++){
        echo $x*$z . ' ';
    }
}
?>