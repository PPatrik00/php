<?php
function register(){
    $conn = mysqli_connect("localhost", "root", "", "user");
    if(isset($_POST['submit'])){
        if(!empty($_POST['email']) && !empty($_POST['psw']) && !empty($_POST['psw-repeat']) && !empty($_POST['user_name'])){
        $user_name = strip_tags(trim($_POST['user_name']));
        $password = strip_tags(trim($_POST['psw']));
        $password_repeat = strip_tags(trim($_POST['psw-repeat']));
        $email = strip_tags(trim($_POST['email']));
            
            $sql = "SELECT `email`, `user_name` FROM `user` WHERE `user_name`='".$user_name."' OR `email`='".$email."'";
            $result = mysqli_query($conn, $sql);
            
            if(mysqli_num_rows($result) >= 1) {
                if($password == $password_repeat){
                    if(strlen($password) <= 8){
                
                        $sql = "INSERT INTO `user` (user_name, password, email,) VALUES ('{$email}', '{$password}', '{$user_name}')";
                        mysqli_query($conn, $sql);
                }else{
                    echo "Legalább 8 karakter hosszúságú jelszót adjon meg!";    
                }
                }else{
                    echo "A két jelszó nem egyezik!";
                }
                }else{
                    echo "Az email vagy a felhasználónév foglalt!";
                }
        }
    }
}
register();
?>
<!doctype html>
<html>
    <head>
    <body>
    <form action="" method="post">
  <div class="container">
    <label for="email"><b>Email</b></label>
    <input type="text" name="email">
    <label for="email"><b>Username</b></label>
    <input type="text" name="user_name">
    <label for="psw"><b>Password</b></label>
    <input type="password" name="psw">
    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" name="psw-repeat">
    <button name="submit" type="submit" class="registerbtn">Register</button>
  </div>
</form> 
    </body>
    </head>
</html>