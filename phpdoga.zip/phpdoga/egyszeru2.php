<?php
function megszerkesztheto(){
    if(isset($_POST['submit'])){
        $a = $_POST['a'];
        $b = $_POST['b'];
        $c = $_POST['c'];
        $x = $_POST['x'];
        $y = $_POST['y'];
        $z = $_POST['z'];

        if (($a + $b > $c) && ($a + $c > $b) && ($b + $c > $a)) {
            echo "Megszerkeszthető!";
        } else{
            echo "Nem szerkeszthető meg!";
        }
        if($x==90 OR $y==90 OR $z==90){
            echo "Derékszögű";
        }
        if($x>90 OR $y>90 OR $z>90){
            echo "Tompaszögű";
        }
        if($x<90 && $y<90 && $z<90){
            echo "Hegyesszögű";
        }
    }
}
megszerkesztheto();
?>

<!doctype html>
<html>
<head>
    <body>
    <form action="" method="post">
    <input type="text" name="a" placeholder="A oldal">
    <input type="text" name="b" placeholder="B oldal">
    <input type="text" name="c" placeholder="C oldal">
    <input type="text" name="x" placeholder="x szög">
    <input type="text" name="y" placeholder="y szög">
    <input type="text" name="z" placeholder="z szög">
    <button name="submit" type="submit">Elküld</button>
    </form>
    </body>
    </head>
</html>