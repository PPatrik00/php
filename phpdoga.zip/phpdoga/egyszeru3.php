<?php

    
    $varosok = array("New York", "Pécs", "Budapest");

foreach($varosok as $varos){
  echo $varos . '<br>';
        

?>