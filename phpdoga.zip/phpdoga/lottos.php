<?php
$elso = 10;
$masodik = 30;
$harmadik = 22;
$negyedik = 67;
$otodik = 85;

for($z = 0; $z<5; $z++){
    $rand = rand(1, 90);
    echo $rand . " ";
}
?>